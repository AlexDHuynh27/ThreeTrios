Overview:
    The Following code contains the logic and rules of the game, Three Trios. The Code allows access
to immutable copies of data as well functionality to play the game.


Quick Start:
To play a game of ThreeTrios first

Key Components:

The Model -
Cards -
Cells -
ConfigReaders -
Player -


Key Subcomponents:



Source Organization:
