package cs3500.threetrios.model.battlerules;

import cs3500.threetrios.model.VariantThreeTriosModel;
import cs3500.threetrios.model.card.Card;
import cs3500.threetrios.model.card.Direction;
import cs3500.threetrios.model.cell.CardCell;
import cs3500.threetrios.model.cell.Cell;
import java.util.ArrayList;
import java.util.List;

/**
 * The StandardBattleRule now replicates the logic of the original ThreeTriosGameModel's
 * battle method, but encapsulated in the applyRule method. This means it:
 * 1. Takes the placed card and its position.
 * 2. Initiates a queue with that position.
 * 3. While the queue is not empty, processes each attacking position:
 *    - Checks NORTH, SOUTH, EAST, WEST directions
 *    - Calls battleCell to determine if a flip should occur
 *    - If flipped, adds that card’s position to the queue for potential combos
 */
public class StandardBattleRule implements BattleRule {
  @Override
  public List<List<Cell>> applyRule(Card placedCard, int row, int col, VariantThreeTriosModel model) {
    List<List<Cell>> grid = model.getGrid();

    // A queue of positions that are currently "attacking" positions
    List<int[]> attackingPositions = new ArrayList<>();
    attackingPositions.add(new int[]{row, col});

    int[][] directions = {
            {-1, 0, Direction.NORTH.ordinal()},
            {1, 0, Direction.SOUTH.ordinal()},
            {0, -1, Direction.WEST.ordinal()},
            {0, 1, Direction.EAST.ordinal()}
    };

    // Process until no more combos
    while (!attackingPositions.isEmpty()) {
      int[] pos = attackingPositions.remove(0);
      int attackRow = pos[0];
      int attackCol = pos[1];

      // For each direction, attempt a battle
      for (int[] dir : directions) {
        int targetRow = attackRow + dir[0];
        int targetCol = attackCol + dir[1];
        Direction direction = Direction.values()[dir[2]];
        processBattle(grid, placedCard, attackRow, attackCol, targetRow, targetCol, direction, attackingPositions);
      }
    }

    return grid;
  }

  /**
   * Attempts to battle the card at (attackRow, attackCol) against the card at (targetRow, targetCol)
   * in the given direction. If battleCell returns true (meaning a flip should occur):
   * - Flip the target cell’s card
   * - Check the color. If not correct, flip again.
   * - Add the target cell to attackingPositions for combo effects.
   */
  private void processBattle(List<List<Cell>> grid, Card placedCard,
                             int attackRow, int attackCol, int targetRow, int targetCol,
                             Direction direction, List<int[]> attackingPositions) {
    if (targetRow < 0 || targetRow >= grid.size() || targetCol < 0 || targetCol >= grid.get(targetRow).size()) {
      return; // Out of bounds
    }

    Cell attackCell = grid.get(attackRow).get(attackCol);
    Cell targetCell = grid.get(targetRow).get(targetCol);

    // Only do something if target is a CardCell with a card
    if (targetCell instanceof CardCell && !targetCell.isEmpty()) {
      // battleCell checks if the attacker's card beats the defender's card in that direction
      if (attackCell.battleCell(targetCell, direction)) {
        // Flip the card once
        ((CardCell) targetCell).flipCell();

        // Check if the flipped card now matches placedCard's color
        if (!targetCell.getCard().getColor().equals(placedCard.getColor())) {
          // Flip again if needed
          ((CardCell) targetCell).flipCell();
        }

        // Add this newly flipped card to the queue, just like the original logic,
        // so combos can propagate
        attackingPositions.add(new int[]{targetRow, targetCol});
      }
    }
  }
}