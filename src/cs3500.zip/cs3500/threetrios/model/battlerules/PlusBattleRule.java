package cs3500.threetrios.model.battlerules;

import cs3500.threetrios.model.VariantThreeTriosModel;
import cs3500.threetrios.model.card.Card;
import cs3500.threetrios.model.card.Direction;
import cs3500.threetrios.model.cell.CardCell;
import cs3500.threetrios.model.cell.Cell;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlusBattleRule extends BattleRuleDecorator {
  public PlusBattleRule(BattleRule decoratedRule) {
    super(decoratedRule);
  }

  @Override
  public List<List<Cell>> applyRule(Card placedCard, int row, int col, VariantThreeTriosModel model) {
    List<List<Cell>> grid = super.applyRule(placedCard, row, col, model);

    Map<Integer, List<Cell>> sumMap = new HashMap<>();
    for (Direction dir : Direction.values()) {
      Cell adjacentCell = model.getAdjacentCell(row, col, dir);
      if (adjacentCell instanceof CardCell && adjacentCell.getCard() != null) {
        Card adjacentCard = adjacentCell.getCard();
        int sum = placedCard.getAttack(dir) + adjacentCard.getAttack(dir.getOpposite());
        sumMap.computeIfAbsent(sum, k -> new ArrayList<>()).add(adjacentCell);
      }
    }

    // If at least two adjacent cards share the same sum, flip those that belong to the opponent
    for (Map.Entry<Integer, List<Cell>> entry : sumMap.entrySet()) {
      List<Cell> cellsWithThisSum = entry.getValue();
      if (cellsWithThisSum.size() >= 2) {
        for (Cell c : cellsWithThisSum) {
          Card adjCard = c.getCard();
          if (adjCard != null && !adjCard.getColor().equals(placedCard.getColor())) {
            ((CardCell) c).flipCell();
            if (!c.getCard().getColor().equals(placedCard.getColor())) {
              ((CardCell) c).flipCell();
            }
          }
        }
      }
    }

    return grid;
  }
}