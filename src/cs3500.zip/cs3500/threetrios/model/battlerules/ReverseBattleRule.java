package cs3500.threetrios.model.battlerules;

import cs3500.threetrios.model.VariantThreeTriosModel;
import cs3500.threetrios.model.card.Card;
import cs3500.threetrios.model.card.Direction;
import cs3500.threetrios.model.cell.CardCell;
import cs3500.threetrios.model.cell.Cell;
import java.util.List;

public class ReverseBattleRule extends BattleRuleDecorator {
  public ReverseBattleRule(BattleRule decoratedRule) {
    super(decoratedRule);
  }

  @Override
  public List<List<Cell>> applyRule(Card placedCard, int row, int col, VariantThreeTriosModel model) {
    List<List<Cell>> grid = super.applyRule(placedCard, row, col, model);

    for (Direction dir : Direction.values()) {
      Cell adjacentCell = model.getAdjacentCell(row, col, dir);
      if (adjacentCell instanceof CardCell && adjacentCell.getCard() != null) {
        Card adjacentCard = adjacentCell.getCard();
        int placedAttack = placedCard.getAttack(dir);
        int opponentAttack = adjacentCard.getAttack(dir.getOpposite());

        // Reverse: flip if placedAttack < opponentAttack and it's opponent's card
        if (placedAttack < opponentAttack && !placedCard.getColor().equals(adjacentCard.getColor())) {
          ((CardCell) adjacentCell).flipCell();
          if (!adjacentCell.getCard().getColor().equals(placedCard.getColor())) {
            ((CardCell) adjacentCell).flipCell();
          }
        }
      }
    }

    return grid;
  }
}